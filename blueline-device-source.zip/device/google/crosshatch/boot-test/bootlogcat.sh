#!/system/bin/sh

if [ "$(/system/bin/getprop ro.boot.mode)" = "recovery" ]; then
    exit 0
fi

/system/bin/toybox rm -f /metadata/logcat.txt*
/system/bin/toybox rm -f /metadata/bpfloader-logcat.txt*
/system/bin/toybox rm -f /metadata/bootlogcat.started /metadata/bootlogcat.error /metadata/bpfloader-logcat.error /metadata/bpfloader-state.txt /metadata/boot-vmstate.txt
echo "bootlogcat started" > /metadata/bootlogcat.started

{
    echo "ro.build.type=$(/system/bin/getprop ro.build.type)"
    echo "ro.build.fingerprint=$(/system/bin/getprop ro.build.fingerprint)"
    echo "ro.boot.slot_suffix=$(/system/bin/getprop ro.boot.slot_suffix)"
    echo "ro.bpf.kver_override=$(/system/bin/getprop ro.bpf.kver_override)"
    echo "ro.bpf.log_to_logcat=$(/system/bin/getprop ro.bpf.log_to_logcat)"
} > /metadata/bpfloader-state.txt

# Record whether init actually starts the loader and whether it publishes the
# loaded property. This survives a netd crash loop even if its logs rotate.
(
    previous=""
    count=0
    while [ "$count" -lt 180 ]; do
        state="progs_loaded=$(/system/bin/getprop bpf.progs_loaded) bpfloader=$(/system/bin/getprop init.svc.bpfloader) netd=$(/system/bin/getprop init.svc.netd) boot_completed=$(/system/bin/getprop sys.boot_completed)"
        if [ "$state" != "$previous" ]; then
            printf '%s %s\n' "$(/system/bin/toybox date +%s)" "$state" >> /metadata/bpfloader-state.txt
            previous="$state"
        fi
        [ "$(/system/bin/getprop sys.boot_completed)" = "1" ] && break
        /system/bin/toybox sleep 1
        count=$((count + 1))
    done
) &

# Keep early BPF loader diagnostics separate from the general logcat ring so
# they survive long boot-animation loops and log rotation.
(
    while true; do
        /system/bin/logcat -b all -v threadtime -s \
            bpfloader:V BpfLoader:V BpfLoader-rs:V LibBpfLoader:V libbpf:V \
            NetBpfLoad:V NetBpfLoader:V NetdUpdatable:V init:E apexd:E \
            -f /metadata/bpfloader-logcat.txt -r 1024 -n 2 \
            2>>/metadata/bpfloader-logcat.error
        echo "filtered logcat exited with status $?" >> /metadata/bpfloader-logcat.error
        /system/bin/toybox sleep 2
    done
) &

{
    echo "ro.bpf.kver_override: $(/system/bin/getprop ro.bpf.kver_override)"
    echo "bpf.progs_loaded: $(/system/bin/getprop bpf.progs_loaded)"
    echo "overcommit_memory: $(/system/bin/toybox cat /proc/sys/vm/overcommit_memory 2>/dev/null)"
    echo "mmap_rnd_bits: $(/system/bin/toybox cat /proc/sys/vm/mmap_rnd_bits 2>/dev/null)"
    echo "mmap_rnd_compat_bits: $(/system/bin/toybox cat /proc/sys/vm/mmap_rnd_compat_bits 2>/dev/null)"
    /system/bin/toybox cat /proc/meminfo
} > /metadata/boot-vmstate.txt

while true; do
    /system/bin/logcat -b all -v threadtime -f /metadata/logcat.txt -r 512 -n 2 2>/metadata/bootlogcat.error
    echo "logcat exited with status $?" >> /metadata/bootlogcat.error
    /system/bin/toybox sleep 2
done
