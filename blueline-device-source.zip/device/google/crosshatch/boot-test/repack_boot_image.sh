#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 2 ]]; then
    echo "Usage: $0 <input-boot.img> <output-boot.img>" >&2
    exit 2
fi

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TREE="$(cd -- "$SCRIPT_DIR/../../../.." && pwd)"
INPUT="$(realpath "$1")"
OUTPUT="$(realpath -m "$2")"
HOST_OUT="${ANDROID_HOST_OUT:-$TREE/out/host/linux-x86}"
if [[ -d "$HOST_OUT/bin" ]]; then
    HOST_BIN="$HOST_OUT/bin"
else
    HOST_BIN="$HOST_OUT"
fi
UNPACK="$TREE/system/tools/mkbootimg/unpack_bootimg.py"
MKBOOTIMG="$HOST_BIN/mkbootimg"
AVBTOOL="$HOST_BIN/avbtool"
CPIO="$(command -v cpio || true)"

if [[ "$INPUT" == "$OUTPUT" ]]; then
    echo "Input and output must be different files." >&2
    exit 2
fi
if [[ ! -x "$MKBOOTIMG" || ! -x "$AVBTOOL" || ! -f "$UNPACK" || -z "$CPIO" ]]; then
    echo "Missing Android host tools or cpio; run this from the configured build tree." >&2
    exit 1
fi

if [[ -z "${CLANG:-}" ]]; then
    CLANG="$(find "$TREE/prebuilts/clang/host/linux-x86" -mindepth 3 -maxdepth 3 \
        -type f -path '*/bin/clang' -print | sort -V | tail -n 1)"
fi
if [[ -z "$CLANG" || ! -x "$CLANG" ]]; then
    echo "Could not find the Android Clang compiler; set CLANG to its path." >&2
    exit 1
fi

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
mkdir -p "$WORK/unpacked" "$WORK/ramdisk"

"$CLANG" --target=aarch64-linux-android35 -O2 -ffreestanding -fno-builtin \
    -fno-stack-protector -fno-pic -fno-pie -nostdlib -static \
    -Wl,-e,_start -Wl,--build-id=none \
    "$SCRIPT_DIR/kmsglog.c" -o "$WORK/kmsglog"

mapfile -d '' -t MKBOOTIMG_ARGS < <(
    python3 "$UNPACK" --boot_img "$INPUT" --out "$WORK/unpacked" \
        --format=mkbootimg -0
)

RAMDISK="$WORK/unpacked/ramdisk"
RAMDISK_TYPE="$(file -b "$RAMDISK")"
case "$RAMDISK_TYPE" in
    gzip*) gzip -dc "$RAMDISK" ;;
    LZ4*)  "$HOST_BIN/lz4" -dc "$RAMDISK" ;;
    *) echo "Unsupported ramdisk format: $RAMDISK_TYPE" >&2; exit 1 ;;
esac | (cd "$WORK/ramdisk" && "$CPIO" -idm --no-absolute-filenames 2>/dev/null)

cd "$WORK/ramdisk"
if [[ ! -e init.real && ! -L init.real ]]; then
    mv init init.real
fi
install -m 0750 "$WORK/kmsglog" init
find . -print0 | LC_ALL=C sort -z | \
    "$CPIO" --null -o -H newc --owner=0:0 2>/dev/null | gzip -n -9 > "$RAMDISK"

mkdir -p "$(dirname -- "$OUTPUT")"
"$MKBOOTIMG" "${MKBOOTIMG_ARGS[@]}" -o "$OUTPUT"

# Recreate the boot partition's AVB footer. Android's build adds these three
# boot properties and uses the kernel digest as the deterministic salt.
PARTITION_SIZE="$(stat -c '%s' "$INPUT")"
KERNEL_HASH="$(sha256sum "$WORK/unpacked/kernel" | cut -d ' ' -f 1)"
AVB_PROP_ARGS=()
while IFS=$'\t' read -r key value; do
    [[ -n "$key" ]] && AVB_PROP_ARGS+=(--prop "$key:$value")
done < <(python3 - "$AVBTOOL" "$INPUT" <<'PY'
import re
import subprocess
import sys

tool, image = sys.argv[1:]
info = subprocess.check_output([tool, "info_image", "--image", image], text=True)
for line in info.splitlines():
    match = re.match(r"\s*Prop:\s+([^ ]+)\s+->\s+'(.*)'$", line)
    if match and match.group(1).startswith("com.android.build.boot."):
        print(f"{match.group(1)}\t{match.group(2)}")
PY
)
if [[ ${#AVB_PROP_ARGS[@]} -eq 0 ]]; then
    echo "Could not read boot AVB properties from the input image." >&2
    exit 1
fi
"$AVBTOOL" add_hash_footer --image "$OUTPUT" \
    --partition_size "$PARTITION_SIZE" --partition_name boot \
    --algorithm NONE --salt "$KERNEL_HASH" "${AVB_PROP_ARGS[@]}"

if [[ "$(stat -c '%s' "$OUTPUT")" != "$PARTITION_SIZE" ]]; then
    echo "AVB image size does not match the boot partition size." >&2
    exit 1
fi
"$AVBTOOL" info_image --image "$OUTPUT" >/dev/null
echo "Wrote diagnostic boot image: $OUTPUT"
