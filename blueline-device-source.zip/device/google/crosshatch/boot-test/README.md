# Blueline early-boot logger

This temporary Android 17 diagnostic replaces the ramdisk `/init` with a small
freestanding wrapper. Before starting the real first-stage init, it creates and
opens a private `/kmsglog.kmsg` character node in the ramdisk root. The boot
ramdisk's `/dev` is empty at this point, and the logger runs in a private mount
namespace, so `/dev/kmsg` is not available yet. Before execing the original
init (`/init.real`), the wrapper opens a kmsg node and starts an isolated child
that writes to a private metadata mount. Its first relabel attempts happen
before SELinux policy is loaded and return `EOPNOTSUPP`; after policy loads, it
relabels the metadata trace first, then the kmsg node, and continues capture.
It checks the kernel command line first and exits in Recovery, so it cannot
hold `/metadata` open during a factory reset.

The implementation is adapted from the Pixel 3a Android 17 / Linux 4.9
bring-up logger by xbill9. The child is forked from `/init` and inherits the
`init` SELinux domain. It relabels its already-open kmsg node and metadata trace
file when SELinux policy loads, using the narrow relabel permissions in the
device policy:

- [kmsglog.c](https://github.com/xbill9/android_kernel_google_msm-4.9/blob/main/backport-tools/lineage-24.0/boot-test/kmsglog.c)
- [boot-test README](https://github.com/xbill9/android_kernel_google_msm-4.9/blob/main/backport-tools/lineage-24.0/boot-test/README.md)

## Logging regression and repair

The bootlog13 trace is 223 bytes. It records the expected early
`EOPNOTSUPP` relabel results and a successful 42-byte first kmsg read, but not
that record. Bootlog14 added vendor rules for the assumed `labeledfs` metadata
context and kmsg reads. Its first system-boot trace grew to 4,836 bytes, then
stopped after early reserved-memory messages (sequence 49). The current
Recovery view finds no `security.selinux` xattr on that file and labels it
`unlabeled`; the same kernel's Recovery log proceeds well beyond sequence 49.
This leaves two possibilities: the logger stopped persisting as early init
changed SELinux state, or the system boot stopped at that point. The trace has
no panic or call trace to distinguish them.

The next logger revision writes a five-second heartbeat during quiet kmsg
periods for up to three minutes. Its vendor policy explicitly allows init to
relabel the metadata file from either `unlabeled` or `labeledfs`, and to relabel
the kmsg node to `kmsg_device`. The logger handles metadata relabel first in the
read-denial path so it can persist the result before touching the kmsg label.
The early `EOPNOTSUPP` results remain expected before policy initialization.

This matches Android's first-stage init policy-load and domain-transition
sequence and its SELinux file-labeling rules:

- [AOSP first-stage init](https://android.googlesource.com/platform/system/core/+/1e7cdf3c7d2733f71a659c215100876168162083/init/init.cpp)
- [Android SELinux implementation](https://source.android.com/docs/security/features/selinux/implement)

The optional timed reboot feature from that logger was removed. This diagnostic
does not schedule a reboot. Each normal Android boot truncates and records its
own kernel trace in `/metadata/boot-kmsg.txt`, capped at 2 MiB. A separate
system init service starts at `post-fs-data` and records rotating logcat
output in `/metadata/logcat.txt`; it includes native crash messages and stack traces that
are absent from `/dev/kmsg`. It leaves `/metadata/bootlogcat.started` to confirm
startup and `/metadata/bootlogcat.error` if logcat exits. Recovery boots skip
both writers, preserving failed-boot logs and allowing data formatting.
Temporary policy rules enable this capture. Remove them along with the
diagnostic boot image once the failure is understood.

For the BPF loader bootloop investigation, the same service also keeps a
separate rotated capture of `NetBpfLoad`, `BpfLoader`, `BpfLoader-rs`,
`NetBpfLoader`, `NetdUpdatable`, init errors, and apexd errors in
`/metadata/bpfloader-logcat.txt`. This preserves early verifier failures even
after the general logcat files rotate past them.

## Build the diagnostic image

First build the normal ROM and its target-files package:

```sh
source build/envsetup.sh
lunch lineage_blueline-cp2a-userdebug
m evolution -j2
m target-files-package -j2
```

Repack the boot image from the target-files staging directory. This is the
image the OTA generator consumes:

```sh
target_files=out/target/product/blueline/obj/PACKAGING/target_files_intermediates/lineage_blueline-target_files
device/google/crosshatch/boot-test/repack_boot_image.sh \
  "$target_files/IMAGES/boot.img" \
  out/target/product/blueline/boot-logger.img
cp out/target/product/blueline/boot-logger.img "$target_files/IMAGES/boot.img"
```

The build regenerates the boot image during packaging, so injecting a ramdisk
before `m evolution` would be overwritten. After replacing `IMAGES/boot.img`,
rebuild root vbmeta from the staged partition images and verify it:

```sh
out/host/linux-x86/bin/avbtool make_vbmeta_image \
  --algorithm SHA256_RSA4096 \
  --key external/avb/test/data/testkey_rsa4096.pem \
  --flags 3 --padding_size 4096 --rollback_index 1793491200 \
  --include_descriptors_from_image "$target_files/IMAGES/boot.img" \
  --include_descriptors_from_image "$target_files/IMAGES/dtbo.img" \
  --include_descriptors_from_image "$target_files/IMAGES/product.img" \
  --include_descriptors_from_image "$target_files/IMAGES/system.img" \
  --include_descriptors_from_image "$target_files/IMAGES/system_ext.img" \
  --include_descriptors_from_image "$target_files/IMAGES/vendor.img" \
  --output "$target_files/IMAGES/vbmeta.img"
out/host/linux-x86/bin/avbtool verify_image \
  --image "$target_files/IMAGES/vbmeta.img" \
  --key external/avb/test/data/testkey_rsa4096.pem
```

For this retrofit device, generate the three sparse block-device images the
OTA releasetools require before building the package. `build_super_image`
places `super_system.img`, `super_vendor.img`, and `super_product.img` in the
target-files `OTA/` directory from the staged partition images and layout:

```sh
mkdir -p "$target_files/OTA"
PATH="$PWD/out/host/linux-x86/bin:$PATH" \
  out/host/linux-x86/bin/build_super_image "$target_files" "$target_files/OTA"
```

Generate the signed full A/B OTA from the target-files directory. Keep the
temporary files on the project filesystem and add the bundled JDK to `PATH` so
the final OTA signing step can find Java:

```sh
export JAVA_HOME="$PWD/prebuilts/jdk/jdk21/linux-x86"
export ANDROID_JAVA_HOME="prebuilts/jdk/jdk21/linux-x86"
export PATH="$JAVA_HOME/bin:$PATH"
tag=bootlog7
export TMPDIR="$PWD/out/tmp/ota-${tag}"
mkdir -p "$TMPDIR"
out/host/linux-x86/bin/ota_from_target_files \
  --package_key build/make/target/product/security/testkey \
  --retrofit_dynamic_partitions \
  --output_metadata_path "out/target/product/blueline/${tag}-ota-metadata.txt" \
  "$target_files" \
  "out/target/product/blueline/EvolutionX-17.0-20261117-blueline-12.4-${tag}-Unofficial.zip"
```

Install that OTA from Evolution Recovery using ADB sideload. Do not fastboot-
flash the diagnostic image.

Before leaving Recovery after sideload, enable Recovery ADB and save its
temporary install log. Recovery's `/tmp/recovery.log` is replaced when it
restarts, so a later log cannot establish the prior package's final status:

```sh
adb pull /tmp/recovery.log out/target/product/blueline/recovery-after-sideload.log
```

After a boot failure, enter Evolution Recovery and enable ADB. Mount metadata
read-only and pull the kernel trace:

```sh
adb shell 'mkdir -p /tmp/meta-ro; mount -t ext4 -o ro,noload /dev/block/by-name/metadata /tmp/meta-ro'
adb pull /tmp/meta-ro/boot-kmsg.txt
adb pull /tmp/meta-ro/logcat.txt
adb pull /tmp/meta-ro/logcat.txt.1
adb pull /tmp/meta-ro/logcat.txt.2
adb pull /tmp/meta-ro/bootlogcat.started
adb pull /tmp/meta-ro/bootlogcat.error
adb pull /tmp/meta-ro/boot-vmstate.txt
adb shell 'umount /tmp/meta-ro'
```

The kernel log is capped at 2 MiB and is replaced on every Android boot. The
logcat files rotate at about 1 MiB each. Recovery does not write to either log,
so entering Recovery to retrieve them leaves the failed Android capture intact.

## Bootlog14 OTA status and first boot

The incremental bootlog14 OTA was rejected by Recovery with status 1 because
update_engine could not find logical-partition metadata in source slot A's
`system_a` device. The recovery log is saved at
`out/target/product/blueline/bootlog-diagnostics/bootlog14-policy-20261118/recovery-after-status1.log`.
A full retrofit A/B package was generated instead:
`out/target/product/blueline/EvolutionX-17.0-20261118-blueline-12.4-bootlog14-full-Retrofit-Unofficial.zip`.
Its ZIP integrity, whole-package signature, and A/B payload signature checks
passed. SHA-256:
`a305af5e83a8353b6cbf747a74347510a851d54c4f17911bd6d684119388be71`.
Host sideload completed with `Total xfer: 1.00x`. The user reported status 1
at Recovery before choosing Yes at the additional-packages prompt, but that
install session's log was not preserved across Recovery's restart. The saved
`recovery-after-status1.log` above belongs to the earlier incremental OTA and
must not be treated as the full-OTA result. After Recovery restarted, slot B
reported the Android 17 fingerprint, and its bootlog14 kernel ran on the first
system-boot attempt. Current Recovery reports slot B active but not yet
successful (`retry_count=5`).

The failed-boot trace is saved at
`out/target/product/blueline/bootlog-diagnostics/bootlog14-policy-20261118/boot-kmsg-after-first-boot-attempt.txt`.
It contains the bootlog14 session header and kernel messages through early
reserved-memory setup (sequence 49), but no panic/oops/call trace. The metadata
directory contains no post-fs-data logcat marker or logcat capture, and
`/sys/fs/pstore` is empty. Recovery's command line confirms it skipped the
logger, preserving the trace. The logger now persists early kernel messages;
the failure still occurs too early for the current trace to identify a cause.

## Bootlog15 follow-up OTA

Bootlog15 adds a five-second heartbeat during quiet kmsg periods, capped at
three minutes. Its vendor policy explicitly allows init to relabel the
metadata file from `unlabeled` and `labeledfs`, and to relabel the kmsg node to
`kmsg_device`. `m vendorimage -j2` completed in 12 minutes 34 seconds, and the
neverallow checks passed. The boot image, vendor image, and root vbmeta hashes
are recorded in `BLUELINE_ANDROID17_PORT.md`; AVB verification passed.

The signed full retrofit A/B package is
`out/target/product/blueline/EvolutionX-17.0-20261118-blueline-12.4-bootlog15-full-Retrofit-Unofficial.zip`.
ZIP integrity, whole-package signature, and A/B payload signature checks
passed. It was installed through Evolution Recovery ADB sideload with status
0. Recovery was running on B; the OTA updated inactive slot A and selected A
for the next boot. Fastboot showed A active and unsuccessful and B successful,
the expected A/B pending-first-boot state. The log's `slot 1` marker identifies
Recovery's running slot B, not the OTA destination. See the
[AOSP A/B update flow](https://source.android.com/docs/core/ota/ab).

The latest slot-A boot attempt returned to Recovery. Its trace is saved at
`out/target/product/blueline/bootlog-diagnostics/bootlog14-policy-20261118/boot-kmsg-after-controlled-slot-a-reboot.txt`.
It was freshly written but remains 223 bytes: expected early relabel results,
first kmsg read of 42 bytes, no later records or heartbeat. The trace file is
still unlabeled, pstore is empty, and the post-fs-data logcat marker is absent.
The bootlog15 image does contain heartbeat code, but its header still says
bootlog14. The device now reports three slot-A retries remaining; avoid more
slot-A boot attempts until capture is improved.

### Bootlog16 EINTR diagnostic

The bootlog15 reader's `EINTR` path (`-4`) retried without sleeping or
counting toward the heartbeat. Repeated interrupted reads could explain a
short, unchanged trace, though this is not confirmed as the ROM's boot cause.
Bootlog16 counts interrupted reads toward a separate heartbeat, sleeps between
retries, and uses a distinct `bootlog16` trace header.

The signed full retrofit A/B OTA is
`out/target/product/blueline/EvolutionX-17.0-20261118-blueline-12.4-bootlog16-full-Retrofit-Unofficial.zip`
(2,445,342,016 bytes; SHA-256
`9a96d8e7a8479c927935f71ff35d4f9dbabe927f9f10d00f730200244e1859f3`). ZIP
integrity, whole-package signature, and A/B payload signature checks passed;
AVB verification passed for boot, dtbo, product, system, system_ext, and
vendor. Evolution Recovery sideload completed with status 0; its saved log is
`out/target/product/blueline/bootlog-diagnostics/bootlog14-policy-20261118/recovery-after-bootlog16-sideload.log`.
Recovery was running on A, and fastboot confirmed B active and unsuccessful
(`retry_count=7`) with A still successful. The first boot from B is underway;
the host has seen ADB as `unauthorized` for over two minutes, so Android may be
running but a complete boot is not confirmed. There is no bootlog16 trace yet.
Wait for the screen state or authorized ADB before another reboot.

### Current update (2026-11-19)

The status-0 bootlog16 install was followed by a failed first boot back to
Evolution Recovery. Slot B is active but unsuccessful with five retries
remaining. Its 223-byte trace stops after the first 42-byte kmsg read, so the
EINTR fix did not restore continued logging. Do not attempt another boot until
a new diagnostic image is ready.

The early logger was forked by the custom `/init` wrapper before SELinux policy
loading, so its child retained the kernel domain while the vendor permissions
were assigned to `init`. Bootlog17 moves capture to a separate vendor init
service, `bootkmsgd`, launched after policy loading in its own daemon domain.
It is intended to append a bounded kernel capture and heartbeats to
`/metadata/boot-kmsg-stage2.txt`. The vendor image build is still in Soong; no
bootlog17 OTA exists yet. The phone remains in Evolution Recovery on slot B.

### Follow-up diagnostic (2026-11-19)

Bootlog17 was subsequently packaged as a full retrofit OTA and installed from
Evolution Recovery with status 0. The failed Android boot returned to Recovery
on slot B with `slot_successful=no` and four retries remaining. Its persisted
trace is saved under
`out/target/product/blueline/bootlog-diagnostics/current-recovery-session/`.

The trace contains a kernel `WARN` at about 310 ms for the `fsync_enabled`
sysfs attribute's invalid mode `0755`. The backtrace proceeds through
`internal_create_group`, `sysfs_create_group`, `param_sysfs_init`, and
`kernel_init_freeable`; the kernel continued booting, so this warning is not
evidence of the boot-stopping fault. The early logger then flooded its own
trace with 51,801 `metadata relabel result -13` messages. Its forked child runs
in the `kernel` SELinux domain, while the code was trying to relabel the
metadata file to `boot_kmsglog_file`; current policy grants the kernel domain
write access to `metadata_file` but not that relabel. The stage-two logger was
also started at `early-init`, before cold-boot device labeling finished, and
its first `/dev/kmsg` open failed with `EACCES`.

Bootlog18 keeps the early trace under its existing `metadata_file` label,
relabels only the private kmsg node, and starts the stage-two reader after
`ro.cold_boot_done=true` with bounded retries opening `/dev/kmsg`. The image
build completed successfully, including kernel, DTBO, and SELinux-policy
targets. The signed full retrofit OTA is
`out/target/product/blueline/EvolutionX-17.0-20261119-blueline-12.4-bootlog18-logger-fix-Retrofit-Unofficial.zip`;
its AVB descriptors, whole-package signature, A/B payload signature, and ZIP
integrity have all verified. It is ready for an official Evolution Recovery
ADB sideload. The trace still does not identify the Android boot failure; it
shows the logger defects and a nonfatal kernel warning.

### BPF-loader boot diagnostics (2026-11-21)

Bootlog22 was installed through Evolution Recovery ADB sideload with status 0.
Its filtered logcat repeatedly records `NetdUpdatable` failing to find
`/sys/fs/bpf/netd_shared/prog_netd_skfilter_allowlist_xtbpf`; `netd` then
restarts roughly every five seconds and init kills both zygotes. The suspend
service also waits for `bpf.progs_loaded`. This explains the persistent
Evolution boot animation, but not why the program was not loaded. Bootlog22's
target-files package still contained the stock ramdisk `/init`, so it did not
include the custom early kernel logger.

Bootlog23 was rebuilt with the repacked boot image and a regenerated root
`vbmeta`. Its status-0 install selected slot A from source slot B. The custom
`/init` wrapper wrote `/metadata/boot-kmsg.txt`, confirming the repack worked,
but that trace stopped during the first second of kernel startup; the expected
`boot-kmsg-stage3.txt` file was absent. The filtered logcat captured the
`NetdUpdatable` failure but not BPF-loader diagnostics. AOSP's Rust loader sets
its log tag to `BpfLoader-rs` in `system/bpf/loader/bpfloader.rs`; the filter
had omitted that exact tag. The filter now includes it for the next capture.

Bootlog22 and Bootlog23 captures, saved install logs, package signatures, and
the corrected OTA are under
`out/target/product/blueline/bootlog-diagnostics/`.

### Bootlog24 failure and logger correction (2026-11-21)

Bootlog24 was installed from Evolution Recovery with status 0 and attempted
Android on slot B. The saved logcat confirms that the product property
`ro.bpf.kver_override=5.4.302` reached the failed boot, so the BPF loader did
not simply see the physical 4.9 version. `NetdUpdatable` still reports the
missing `prog_netd_skfilter_allowlist_xtbpf`, `netd` aborts on each retry, and
the suspend service reports that `bpf.progs_loaded` is still unset. This
confirms the BPF initialization path is incomplete but does not identify which
earlier BPF object or verifier check stopped it.

The bootlog24 capture contains only the first 0.77 seconds of kernel messages;
`boot-kmsg-stage3.txt` was never created. The service waited for
`ro.cold_boot_done=true`, while the boot was waiting for `bpf.progs_loaded`, so
the logger could not capture the BPF loader's kernel output. Android 17's
`NetBpfLoad` also selects `KernelLogger`, which bypassed the filtered logcat
capture. The next diagnostic build starts `bootkmsgd` at `post-fs-data`, skips
its file open in Recovery, and opts Blueline into normal logcat output for
`NetBpfLoad`. This should capture both the loader's specific failure and any
kernel verifier details during the next official sideload boot test.

### Bootlog25 BPF capture OTA (2026-11-21)

The bootlog24 properties confirm `ro.bpf.kver_override=5.4.302` was already
present during the failed boot, so the loader failure is not explained by the
4.9 kernel version alone. Bootlog25 keeps that override, opts `NetBpfLoad`
into logcat for this device, and starts `bootkmsgd` at `post-fs-data` so it
does not depend on `ro.cold_boot_done` becoming true. Its Recovery guard keeps
logger startup from interfering with recovery operations.

The target-files build completed successfully with
`lunch lineage_blueline-cp2a-userdebug` and `m target-files-package -j2`.
Boot image repacking and root `vbmeta` regeneration completed; AVB verification
passed for boot, dtbo, product, system, system_ext, and vendor. The signed
full retrofit A/B OTA is
`out/target/product/blueline/EvolutionX-17.0-20261121-blueline-12.4-bootlog25-bpf-capture-full-Retrofit-Unofficial.zip`.
ZIP integrity, whole-package signature, and A/B payload signature checks
passed. SHA-256:
`3edbd28f0c2b30a3833fb672f6c565b3eca5fac3329cbe83b191e609cac07214`.

The OTA was installed through Evolution Recovery ADB sideload with status 0.
The saved install log is
`out/target/product/blueline/bootlog-diagnostics/bootlog25-bpf-capture/recovery-after-sideload.log`.
Recovery was on slot B and update_engine explicitly targeted slot A. After
the system reboot, the user saw a moving Evolution animation at five minutes;
ADB and fastboot remained unavailable after about eight minutes. Recovery
ADB is now available on slot A, and the new metadata logs are saved under
`out/target/product/blueline/bootlog-diagnostics/bootlog25-bpf-capture/post-first-boot/`.

The first `NetBpfLoad` attempt logged `kver:504012e`, `uid:0`, then
`bpfGetNextProgId(zero) returned 0 (errno 22)` and exited with return code 32
before reaching `loadAllObjects()`. The physical 4.9 kernel's `bpf_cmd` enum
ends at `BPF_PROG_DETACH` and its syscall dispatcher returns `-EINVAL` for
unknown commands; it has neither `BPF_PROG_GET_NEXT_ID` nor
`BPF_MAP_GET_NEXT_ID`. The 5.4.302 `ro.bpf.kver_override` changes Android's
version-based feature decisions but does not add those kernel syscalls. This
early loader exit explains why netd cannot open
`/sys/fs/bpf/netd_shared/prog_netd_skfilter_allowlist_xtbpf`, then repeatedly
crashes and restarts zygotes.

The stage-three kernel logger also failed to open `/dev/kmsg` with `EACCES`.
Its domain had `kmsg_device` file access but lacked `kernel:system syslog_read`.
Bootlog26 adds that permission and makes the root-mode sanity check skip only
the unsupported ID-enumeration operation on `EINVAL`, allowing the loader to
continue into `loadAllObjects()` and capture the next real kernel/API failure.
This is a diagnostic compatibility step, not evidence that all Android 17
BPF requirements are satisfied by 4.9.

Bootlog26 was installed through official Evolution Recovery sideload onto slot
B and completed with status 0. Its first-boot capture is under
`out/target/product/blueline/bootlog-diagnostics/bootlog26-bpf-enum-fix/post-first-boot/attempt1/`.
Skipping the unsupported program-ID enumeration exposed the next blocker:
`ro.bpf.kver_override=5.4.302` caused `NetBpfLoad` to issue `BPF_BTF_LOAD`,
but the running `4.9.337` kernel has no such command. Loading `offload.o`
failed with `EINVAL`, so the netd allowlist program was never pinned. `netd`
then aborted repeatedly, and init restarted zygote, leaving the device on the
Evolution animation. The stage-three `/dev/kmsg` capture now works; its SELinux
read permission change is confirmed.

Bootlog27 keeps the 5.4 override for Android's mainline APEX minimum check but
gates BTF loading on the actual `uname` release. This isolates actual BPF
syscall support from the advertised minimum version; it is still a diagnostic
compatibility step and does not imply that Android 17's BPF requirements are
met by the 4.9 kernel.

Bootlog27 was installed through Evolution Recovery with status 0. Recovery was
on slot B and the OTA targeted slot A. The phone stayed on the moving Evolution
boot animation; after returning to Recovery, the stage-three logs were pulled
from `/metadata` into
`out/target/product/blueline/bootlog-diagnostics/bootlog27-btf-gate/post-first-boot/attempt1/`.
The loader now gets past BTF handling, but `offload.o` still fails while
creating `tether_error_map`:

```
bpf_create_map[tether_error_map] btf:0 -> -1 errno:22
```

The source explains the `EINVAL`: the loader sets `bpf_attr.map_name` whenever
the advertised version is at least 4.15. On this device, that override is
5.4.302, but the running 4.9.337 kernel's `BPF_MAP_CREATE` attribute ends at
`map_flags`; its `CHECK_ATTR` rejects nonzero bytes after that field. The map
itself is a supported ARRAY with zero flags, so the name field is the mismatch.
The same 4.9 ABI lacks `prog_name` and `BPF_OBJ_GET_INFO_BY_FD`, so checking
only map creation would expose later failures.

The next source revision separates advertised kernel-version policy from
actual-kernel ABI checks across `NetBpfLoad`, `BpfHandler`, and the BPF map
wrappers. It uses the running kernel release to guard BPF request fields,
commands, map types, and optional operations that the Pixel 3's 4.9 source
does not implement. Kernel-versioned map and program variants still use the
5.4 override, as in the Pixel 3a reference port, and the override remains in
place for Android's mainline APEX policy checks. The loader's startup log will
record both versions so subsequent captures can confirm the distinction.
This is a compatibility experiment; it is not a claim that 4.9 satisfies
Android 17's complete BPF requirements.

### Bootlog28: runtime BPF compatibility (2026-11-21)

Bootlog27's saved loader trace showed that the physical kernel is
`4.9.337-✨Caelum-b1c1` while Android's BPF version override advertises
`5.4.302`. BTF loading is now skipped, but the first map creation still failed
with `EINVAL`: `NetBpfLoad` populated the newer `map_name` field in
`BPF_MAP_CREATE`, while this kernel's attribute validation ends at `map_flags`.
That stopped BPF initialization, left netd's required allowlist program
unpinned, and caused netd and zygote restarts during the stuck boot.

The Pixel 3a Android 17 port provides a useful precedent: it also runs a
4.9.337 kernel and reports a 5.4 BPF baseline. Its published changes keep the
advertised version for selecting compatible map/program variants, extend the
5.4 netd statistics programs to Android 17, and skip ring-buffer consumers
when the kernel cannot create their maps. See the [port write-up](https://dev.to/gde/android-17-on-a-49-kernel-lineageos-240-on-the-pixel-3a-1mok),
its [Connectivity change](https://github.com/xbill9/android_packages_modules_Connectivity/commit/5c298de),
and its [non-critical ring-buffer test change](https://github.com/xbill9/android_system_bpf/commit/72b37ef).
Blueline uses a different chipset, so these are compatibility references, not
a device-tree drop-in.

Bootlog28 keeps the 5.4 override for Android policy and versioned BPF
selection, while using the actual running release to gate BPF request fields,
syscalls, optional map types, and bulk operations. It also carries the
5.4-statistics and missing-ring-buffer handling above. The local 4.9 kernel's
`cgroup_bpf` structure does not contain the reference port's BPF reference
counter, and Bootlog27 has no matching percpu-ref warning, so that separate
kernel fix was not copied without evidence. The 4.9 `CHECK_ATTR` behavior is
visible in the [Android common kernel source](https://android.googlesource.com/kernel/common/+/8539bb173f20e0098c93bbf135394629f7882f70/kernel/bpf/syscall.c); current BPF map attributes are described in the [Linux BPF map documentation](https://kernel.org/doc/html/next/bpf/maps.html).

Several other compatibility pieces described by the reference port are already
in this tree: init/vold's legacy fscrypt session-keyring path, Blueline's
`LEGACY_GRALLOC` setting, and vendor ION labeling/access rules. If the BPF
loader now passes, the next saved boot trace should show whether any remaining
native app-zygote or hardware-specific issues need separate treatment.

The Bootlog28 target-files build and signed full retrofit OTA completed.
ZIP integrity, whole-package signature, and A/B payload signature checks all
passed. Evolution Recovery sideload completed with host result `Total xfer:
1.00x` and on-device status 0. Recovery ran from slot A and the OTA wrote
slot B.

The Bootlog28 first-boot trace confirms the `tether_error_map` problem is
resolved: `NetBpfLoad` reused it successfully (fd 4), rather than failing
creation with `EINVAL`. It then stopped in the map-reuse branch before loading
and pinning the required allowlist program. The checked-in branch contains an
unconditional `abort()` immediately after the reuse log; this predates the
Bootlog28 compatibility changes and explains why netd continued to abort and
init restarted zygote. Bootlog29 removes that abort so map validation and BPF
program loading can proceed.

The same trace has a separate camera HAL failure: `camera.sdm845.so` crashes
in `CamX::TuningDataManager::GetChromatix()` after camera EEPROM checksum and
sensor-read errors. It may explain the known rear-camera fault, but the
repeated `netd` abort and zygote restarts are the observed reason Android
remained at the Evolution animation. Recovery also reported an ext4 bad extent
header for the metadata partition while reading `logcat.txt`; the kernel,
BPF-specific, and rotated logcat traces were saved. Logs and package details
are under
`out/target/product/blueline/bootlog-diagnostics/bootlog28-runtime-version-gates/`.

### Bootlog29: continue after reusing a pinned map

Removed the unconditional abort from `NetBpfLoad::createMaps()`' pinned-map
reuse path. The successful Bootlog28 `tether_error_map` reuse exercised this
path for the first time; it must continue to map validation, pinning, and
program loading.

The incremental `target-files-package` build completed successfully. A signed
full retrofit OTA was generated at
`out/target/product/blueline/EvolutionX-17.0-20261121-blueline-12.4-bootlog29-map-reuse-fix-full-Retrofit-Unofficial.zip`.
ZIP integrity, whole-package signature, and A/B payload signature checks all
passed; its SHA-256 is
`0ed64972668c09feed99c3a081f06f20f4bb2ad46ade9ac79aa0662f01e2db7b`.
Evolution Recovery sideload completed with status 0. Recovery ran from slot
`_b` and wrote the target partitions on `_a`; the install log records
successful filesystem verification and post-install commands. The Bootlog29
first boot returned to Recovery after the same Evolution animation hang. Its
trace confirms the abort removal let `tether_error_map` open successfully
(fd 4), but `createMaps()` then tried to pin that existing map at the same
path and got `EEXIST` (`errno 17`). The loader stopped before loading netd's
allowlist program; `NetdUpdatable` repeatedly reported the program missing and
netd aborted, triggering zygote restarts. Bootlog30 now skips only the
redundant pin/create/rename when `createMaps()` reuses an existing pin, while
retaining map validation and the permission/ownership and map-id handling. Its
target-files rebuild is next. See
`out/target/product/blueline/bootlog-diagnostics/bootlog29-map-reuse-fix/VERIFICATION.md`
for the package checks and first-boot evidence.

### Bootlog30 first-boot result: the required tether program is rejected

The Bootlog30 Recovery sideload completed with status 0. Its first boot got past
map reuse: `NetBpfLoad` reopened the existing tether maps, then the required
`schedcls_tether_downstream6_ether` program failed `BPF_PROG_LOAD` with
`Permission denied`. The loader stopped before it could pin the netd allowlist
program, so `NetdUpdatable` repeatedly failed to open
`/sys/fs/bpf/netd_shared/prog_netd_skfilter_allowlist_xtbpf`; netd then aborted
and init restarted zygote. This is the observed cause of that boot stall.

The trace marked the program-load verifier output as multiline, but the
individual verifier lines were absent. That image reported `isUser=true`, and
the loader only writes the verifier buffer to logcat for non-user builds. The
current product already sets `ro.bpf.log_to_logcat=true`, but the loader did
not consult it. The Nov. 23 follow-up boot also returned to Recovery with the
same missing-allowlist/netd crash pattern; its old logger had wrapped the
early kernel trace, so it did not preserve the loader's first failure.

### Bootlog31: preserve the verifier failure

Bootlog31 makes the explicit `ro.bpf.log_to_logcat=true` property enable the
verifier buffer even on a user-variant image. It enlarges the dedicated BPF
log rotation, records build type/fingerprint/slot and BPF startup properties,
and keeps the earliest kernel messages instead of wrapping them. The capture
window ends after three minutes, after the boot-time BPF loader has run. This
diagnostic revision does not yet change the program-selection or kernel code;
the verifier output will identify the compatibility fix to port next.

The Nov. 23 Recovery pull is saved under
`out/target/product/blueline/bootlog-diagnostics/bootlog30-reuse-no-repin/post-first-boot/attempt2-20261123-recovery/`.
Recovery's metadata filesystem was mounted read-only without journal replay,
so the stage-three kmsg file returned an I/O error. Its raw partition copy was
used only in temporary storage and has been removed after extracting the
diagnostic tail. The copied logcat files are intact.

### Bootlog31 package (2026-11-23)

The full Android 17 build and target-files packaging completed successfully.
Bootlog31 changes BPF verifier logging and first-boot log capture only; it does
not yet change BPF program compatibility or the kernel. Its signed full retrofit
A/B OTA is
`out/target/product/blueline/EvolutionX-17.0-20261123-blueline-bootlog31-full-Retrofit-Unofficial.zip`.

The OTA tool requires retrofit block-device images under `target_files/OTA/`.
Generate them from the current staged partition images with
`out/host/linux-x86/bin/build_super_image "$target_files" "$target_files/OTA"`
before running `ota_from_target_files`. Run the OTA tool with the bundled JDK
on `PATH` and `TMPDIR` inside `out/`; `/tmp` is a smaller tmpfs and cannot hold
the working copy of these target files.

The package is 2,449,682,320 bytes with SHA-256
`6038f56868565f7926706ffb57ea53d4f09f152196670e02cc11b5c2b12dde03`. ZIP
integrity, the whole-package signature, and A/B payload signatures all passed.
The root vbmeta image also passed `avbtool verify_image`. Detailed outputs are
in `out/target/product/blueline/bootlog-diagnostics/bootlog31-verifier/`.
Evolution Recovery sideload completed with host result `Total xfer: 1.00x`
and on-device status 0. Recovery ran from slot `_a`; the verified partition
paths show the OTA targeted slot `_b`. The first boot remained on the animated
Evolution logo and was returned to Recovery after several minutes.

### Bootlog31 first-boot diagnosis (2026-11-23)

Recovery ADB confirmed active slot `_b` and the Android 17 build fingerprint.
The metadata partition was mounted read-only with journal replay disabled, and
the saved capture was pulled to
`out/target/product/blueline/bootlog-diagnostics/bootlog31-verifier/post-first-boot/metadata-repull-20261123-recovery/`.
The stage-three kmsg, BPF state, and rotated logcat hashes match the earlier
Bootlog31 pull exactly, so this Recovery session did not produce an independent
new boot trace.

The captured trace shows `netbpfload` starting, warning that Android 25Q4
expects kernel 5.10, and then failing to open
`/proc/sys/net/core/bpf_jit_kallsyms` with `ENOENT`. The `bpfloader` service
exits with status 25 before any BPF programs load. The saved state has an empty
`progs_loaded` value and `netd` repeatedly restarting; its required pinned
allowlist program is unavailable, and zygote is restarted during the prolonged
boot animation.

The selected B1C1 kernel already has `bpf_jit_kallsyms`, `CONFIG_BPF_JIT`, and
`CONFIG_HAVE_EBPF_JIT`, but its `net_core_table` omitted the sysctl entry. The
XDA-derived local 4.9 reference exposes it. B1C1 now exposes the same setting
with mode `0600`, a `CAP_SYS_ADMIN`-restricted handler, and a 0–1 value range.
This directly addresses the first fatal BPF-loader error in the trace. The
next build and official Recovery sideload must confirm whether boot proceeds;
the 5.10 compatibility warning may expose later missing-kernel requirements.
