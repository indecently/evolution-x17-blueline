/*
 * kmsglog: stand-in /init for boot tests. Mounts the metadata partition,
 * captures kernel messages to /metadata/boot-kmsg.txt with O_SYNC writes, then
 * execs the real first-stage init (/init.real) as PID 1.
 * Freestanding: raw aarch64 syscalls, no libc.
 */
typedef unsigned long u64;
typedef long s64;

#define AT_FDCWD (-100)
#define O_RDONLY 0
#define O_WRONLY 1
#define O_CREAT 0100
#define O_TRUNC 01000
#define O_APPEND 02000
#define O_SYNC 04010000
#define O_NONBLOCK 04000
#define O_DIRECTORY 040000	/* arm64 value */
#define S_IFBLK 0060000

static s64 sc6(s64 n, s64 a, s64 b, s64 c, s64 d, s64 e, s64 f)
{
	register s64 x8 asm("x8") = n;
	register s64 x0 asm("x0") = a;
	register s64 x1 asm("x1") = b;
	register s64 x2 asm("x2") = c;
	register s64 x3 asm("x3") = d;
	register s64 x4 asm("x4") = e;
	register s64 x5 asm("x5") = f;
	asm volatile("svc #0" : "+r"(x0) : "r"(x8), "r"(x1), "r"(x2), "r"(x3),
		     "r"(x4), "r"(x5) : "memory");
	return x0;
}
#define sc(n, a, b, c, d) sc6(n, (s64)(a), (s64)(b), (s64)(c), (s64)(d), 0, 0)

#define NR_mkdirat 34
#define NR_mknodat 33
#define NR_fsetxattr 7
#define NR_mount 40
#define NR_openat 56
#define NR_close 57
#define NR_getdents64 61
#define NR_read 63
#define NR_write 64
#define NR_exit 93
#define NR_nanosleep 101
#define NR_clone 220
#define NR_execve 221
#define NR_sync 81
#define NR_syncfs 267
#define NR_ftruncate 46
#define NR_lseek 62

static u64 slen(const char *s) { u64 n = 0; while (s[n]) n++; return n; }
static int sprefix(const char *s, const char *p)
{
	while (*p) if (*s++ != *p++) return 0;
	return 1;
}
static int cmdline_has_token(const char *s, const char *token)
{
	u64 wanted = slen(token);
	while (*s) {
		while (*s == ' ' || *s == '\t' || *s == '\n') s++;
		const char *start = s;
		while (*s && *s != ' ' && *s != '\t' && *s != '\n') s++;
		if ((u64)(s - start) == wanted) {
			u64 i = 0;
			while (i < wanted && start[i] == token[i]) i++;
			if (i == wanted) return 1;
		}
	}
	return 0;
}
static void scopy(char *d, const char *s) { while ((*d++ = *s++)); }
static void scat(char *d, const char *s) { scopy(d + slen(d), s); }
static u64 satou(const char *s)
{
	u64 n = 0;
	while (*s >= '0' && *s <= '9') n = n * 10 + (*s++ - '0');
	return n;
}

#define NR_newfstatat 79

static void nap(s64 ns)
{
	struct { s64 s, ns; } ts = { ns / 1000000000, ns % 1000000000 };
	sc(NR_nanosleep, &ts, 0, 0, 0);
}

/*
 * Recovery's factory reset formats /metadata. Do not mount or hold it from
 * the diagnostic child while Recovery is running. Fail closed if cmdline
 * cannot be read, so an unusual boot mode cannot block a recovery wipe.
 */
static int recovery_boot(void)
{
	static char cmdline[4096];
	int fd = sc(NR_openat, AT_FDCWD, "/proc/cmdline", O_RDONLY, 0);
	if (fd < 0) {
		sc(NR_mkdirat, AT_FDCWD, "/kl", 0755, 0);
		sc(NR_mkdirat, AT_FDCWD, "/kl/probe", 0755, 0);
		sc6(NR_mount, (s64)"proc", (s64)"/kl/probe", (s64)"proc", 0, 0, 0);
		fd = sc(NR_openat, AT_FDCWD, "/kl/probe/cmdline", O_RDONLY, 0);
	}
	if (fd < 0) return 1;
	s64 n = sc(NR_read, fd, cmdline, sizeof(cmdline) - 1, 0);
	sc(NR_close, fd, 0, 0, 0);
	if (n <= 0) return 1;
	cmdline[n] = 0;
	return cmdline_has_token(cmdline, "androidboot.mode=recovery");
}

#define KMSG_CAP (2UL << 20)

static int kin = -1;	/* opened before first-stage init changes /dev */
static int kw = -1;	/* kernel-message device for status lines */
static int early_kmsg_labeled;
static s64 early_kmsg_label_result = -1;
static void say(const char *m)
{
	static char b[128];
	scopy(b, "kmsglog: "); scat(b, m); scat(b, "\n");
	if (kw >= 0) sc(NR_write, kw, b, slen(b), 0);
}
static void sayn(const char *m, s64 v)
{
	static char b[96], d[24];
	int i = 23, neg = v < 0;
	u64 u = neg ? -v : v;
	d[i] = 0;
	do { d[--i] = '0' + u % 10; u /= 10; } while (u);
	if (neg) d[--i] = '-';
	scopy(b, m); scat(b, " "); scat(b, d + i);
	say(b);
}

static s64 write_all(int fd, const char *buf, u64 len)
{
	u64 off = 0;
	while (off < len) {
		s64 n = sc(NR_write, fd, buf + off, len - off, 0);
		if (n < 0) return n;
		if (n == 0) return -5;	/* EIO */
		off += n;
	}
	return 0;
}

/* Persist raw syscall results in metadata; say() is only useful if kmsg works. */
static void write_status(int fd, const char *label, s64 value)
{
	static char b[128], d[24];
	int i = 23, neg = value < 0;
	u64 u = neg ? -value : value;
	d[i] = 0;
	do { d[--i] = '0' + u % 10; u /= 10; } while (u);
	if (neg) d[--i] = '-';
	scopy(b, label);
	scat(b, d + i);
	scat(b, "\n");
	if (fd >= 0) write_all(fd, b, slen(b));
}

static s64 set_selinux_context(int fd, const char *context)
{
	static const char name[] = "security.selinux";
	return sc(NR_fsetxattr, fd, name, context, slen(context) + 1);
}

/* MAJOR/MINOR of the block device whose PARTNAME is metadata, from sysfs at /kl/sys. */
static int find_metadata(int sysfd, u64 *maj, u64 *min)
{
	static char buf[4096], path[256], ue[1024];
	int dfd = sc(NR_openat, sysfd, "class/block", O_RDONLY | O_DIRECTORY, 0);
	if (dfd < 0) return -1;
	for (;;) {
		s64 n = sc(NR_getdents64, dfd, buf, sizeof(buf), 0);
		if (n <= 0) break;
		for (s64 off = 0; off < n;) {
			unsigned short reclen = *(unsigned short *)(buf + off + 16);
			char *name = buf + off + 19;
			off += reclen;
			if (name[0] == '.') continue;
			scopy(path, "class/block/");
			scat(path, name);
			scat(path, "/uevent");
			int fd = sc(NR_openat, sysfd, path, O_RDONLY, 0);
			if (fd < 0) continue;
			s64 r = sc(NR_read, fd, ue, sizeof(ue) - 1, 0);
			sc(NR_close, fd, 0, 0, 0);
			if (r <= 0) continue;
			ue[r] = 0;
			u64 ma = 0, mi = 0; int hit = 0;
			for (char *l = ue; *l;) {
				if (sprefix(l, "MAJOR=")) ma = satou(l + 6);
				if (sprefix(l, "MINOR=")) mi = satou(l + 6);
				if (sprefix(l, "PARTNAME=metadata\n")) hit = 1;
				while (*l && *l != '\n') l++;
				if (*l) l++;
			}
			if (hit) { *maj = ma; *min = mi; sc(NR_close, dfd, 0, 0, 0); return 0; }
		}
	}
	sc(NR_close, dfd, 0, 0, 0);
	return -1;
}

/*
 * Runs in its own mount namespace (see _start), so the sysfs and metadata
 * mounts here are invisible to init.
 */
static void logger(void)
{
	u64 maj, min;
	int i, kmsg_labeled = early_kmsg_labeled;

	int in = kin;
	sayn("started, kmsg fd", in);
	if (recovery_boot()) {
		say("recovery boot or unreadable cmdline; diagnostic writer disabled");
		return;
	}

	/*
	 * init deletes everything on the ramdisk once it switches root, and
	 * removing a mount point detaches the mount even in this namespace.
	 * So hold fds, not paths, and retry if the cleanup wins a race.
	 */
	int sysfd = -1, out = -1;
	for (i = 0; sysfd < 0 && i < 50; i++) {
		sc(NR_mkdirat, AT_FDCWD, "/kl", 0755, 0);
		sc(NR_mkdirat, AT_FDCWD, "/kl/sys", 0755, 0);
		if (sc6(NR_mount, (s64)"sysfs", (s64)"/kl/sys", (s64)"sysfs", 0, 0, 0) == 0)
			sysfd = sc(NR_openat, AT_FDCWD, "/kl/sys", O_RDONLY | O_DIRECTORY, 0);
		if (sysfd < 0) nap(10000000);
	}
	sayn("sysfs fd", sysfd);
	if (sysfd < 0) return;
	for (i = 0; find_metadata(sysfd, &maj, &min) < 0; i++) {
		if (i > 600) { say("metadata partition not found"); return; }
		nap(50000000);
	}
	sayn("metadata minor", min);
	u64 dev = ((maj & 0xfff) << 8) | (min & 0xff) | ((min & ~0xffUL) << 12);
	for (i = 0; out < 0 && i < 100; i++) {
		sc(NR_mkdirat, AT_FDCWD, "/kl", 0755, 0);
		sc(NR_mkdirat, AT_FDCWD, "/kl/mnt", 0755, 0);
		sc(NR_mknodat, AT_FDCWD, "/kl/md", S_IFBLK | 0600, dev);
		s64 r = sc6(NR_mount, (s64)"/kl/md", (s64)"/kl/mnt", (s64)"ext4", 0, 0, 0);
		if (r == 0)
			out = sc(NR_openat, AT_FDCWD, "/kl/mnt/boot-kmsg.txt",
					 O_WRONLY | O_CREAT | O_TRUNC | O_APPEND | O_SYNC, 0644);
		if (i == 0 || out >= 0) sayn("mount metadata", r);
		if (out < 0) nap(50000000);
	}
	sayn("log file fd", out);
	if (out < 0) return;
	static const char hdr[] = "\n===== kmsglog: bootlog26 early stage started =====\n";
	s64 wr = write_all(out, hdr, sizeof(hdr) - 1);
	if (wr < 0) {
		sayn("bootlog26 header write result", wr);
		sc(NR_syncfs, out, 0, 0, 0);
		return;
	}
	write_status(out, "kmsglog: early kmsg relabel result ", early_kmsg_label_result);
	sc(NR_syncfs, out, 0, 0, 0);
	if (in < 0) {
		static const char err[] = "kmsglog: cannot open ramdisk kernel-message node\n";
		write_all(out, err, sizeof(err) - 1);
		sc(NR_syncfs, out, 0, 0, 0);
		return;
	}
	s64 seek_result = sc(NR_lseek, in, 0, 0, 0);
	write_status(out, "kmsglog: kmsg seek result ", seek_result);
	sc(NR_syncfs, out, 0, 0, 0);
	/* Keep a visible marker for the exact logger build being exercised. */
	static const char capture_msg[] = "kmsglog: reading kernel messages\n";
	write_all(out, capture_msg, sizeof(capture_msg) - 1);
	sc(NR_syncfs, out, 0, 0, 0);
	/* Persist each record immediately so a reset cannot discard a buffered batch. */
	static char message[8192];
	s64 end = sc(NR_lseek, out, 0, 2, 0);
	u64 written = end > 0 ? (u64)end : sizeof(hdr) - 1;
	u64 quiet_reads = 0;
	u64 heartbeats = 0;
	u64 kmsg_relabel_attempts = 0;
	int first_read_logged = 0;
	int overrun_logged = 0;
	for (u64 iter = 0;; iter++) {
		if (iter % 50 == 0) sc(NR_syncfs, out, 0, 0, 0);
		s64 n = sc(NR_read, in, message, sizeof(message), 0);
		if (!first_read_logged) {
			write_status(out, "kmsglog: first read result ", n);
			sc(NR_syncfs, out, 0, 0, 0);
			first_read_logged = 1;
		}
		if (n == -32) {			/* EPIPE: the ring wrapped before this reader caught up. */
			if (!overrun_logged) {
				write_status(out, "kmsglog: kmsg overrun result ", n);
				sc(NR_syncfs, out, 0, 0, 0);
				overrun_logged = 1;
			}
			continue;
		}
		if (n == -13) {
			/*
			 * The metadata trace deliberately keeps its metadata_file label;
			 * the kernel domain has explicit write access to that file type.
			 * Once SELinux policy is active, relabel only the private ramdisk
			 * kmsg node so this already-open reader can continue.
			 */
			if (!kmsg_labeled) {
				s64 r = set_selinux_context(in,
						"u:object_r:kmsg_device:s0");
				if (kmsg_relabel_attempts++ == 0) {
					write_status(out, "kmsglog: kmsg node relabel result ", r);
					sc(NR_syncfs, out, 0, 0, 0);
				}
				if (r < 0) {
					if (kmsg_relabel_attempts >= 10) {
						write_status(out, "kmsglog: kmsg relabel retries exhausted after ",
								kmsg_relabel_attempts);
						sc(NR_syncfs, out, 0, 0, 0);
						return;
					}
					nap(100000000);
					continue;
				}
				kmsg_labeled = 1;
				say("kmsg node relabeled as kmsg_device");
			}
			say("resuming kernel capture after SELinux relabel");
			nap(20000000);
			continue;
		}
		if (n == -11) {	/* EAGAIN: no new messages yet. */
			/*
			 * A short heartbeat distinguishes an idle kernel from a logger
			 * that stopped persisting messages during early init. Limit it to
			 * three minutes so a successful boot does not leave a noisy trace.
			 */
			quiet_reads++;
			if (quiet_reads % 250 == 0 && heartbeats < 36) {
				write_status(out, "kmsglog: quiet heartbeat ", ++heartbeats);
				sc(NR_syncfs, out, 0, 0, 0);
			}
			nap(20000000);
			continue;
		}
		if (n == -4) {			/* EINTR: avoid a silent busy loop; count it as a quiet read. */
			quiet_reads++;
			if (quiet_reads % 250 == 0 && heartbeats < 36) {
				write_status(out, "kmsglog: interrupted-read heartbeat ", ++heartbeats);
				sc(NR_syncfs, out, 0, 0, 0);
			}
			nap(20000000);
			continue;
		}
		if (n <= 0) {
			write_status(out, "kmsglog: unexpected read result ", n);
			sc(NR_syncfs, out, 0, 0, 0);
			return;
		}
		quiet_reads = 0;
		/* /metadata also stores keys, so wrap this diagnostic at 2 MiB. */
		if (written + (u64)n > KMSG_CAP) {
			static const char wrap[] = "\n===== kmsglog: wrapped =====\n";
			wr = sc(NR_ftruncate, out, 0, 0, 0);
			if (wr < 0) {
				write_status(out, "kmsglog: metadata truncate result ", wr);
				sc(NR_syncfs, out, 0, 0, 0);
				return;
			}
			wr = write_all(out, wrap, sizeof(wrap) - 1);
			if (wr < 0) return;
			written = sizeof(wrap) - 1;
		}
		wr = write_all(out, message, (u64)n);
		if (wr < 0) {
			write_status(out, "kmsglog: metadata write result ", wr);
			sc(NR_syncfs, out, 0, 0, 0);
			return;
		}
		written += (u64)n;
	}
}

void _start(void)
{
	static char *argv[] = { "/init", 0 };
	static char *envp[] = { 0 };
	/*
	 * Create and open a private kernel-message node before real init can mount
	 * /dev or enable SELinux enforcement. The logger child keeps these fds
	 * across init's switch_root and its own private mount namespace.
	 */
	sc(NR_mknodat, AT_FDCWD, "/kmsglog.kmsg", 0020000 | 0600, (1 << 8) | 11);
	kin = sc(NR_openat, AT_FDCWD, "/kmsglog.kmsg", O_RDONLY | O_NONBLOCK, 0);
	kw = sc(NR_openat, AT_FDCWD, "/kmsglog.kmsg", O_WRONLY, 0);
	if (kin >= 0) {
		early_kmsg_label_result = set_selinux_context(kin,
				"u:object_r:kmsg_device:s0");
		early_kmsg_labeled = early_kmsg_label_result == 0;
		sayn("early kmsg node relabel result", early_kmsg_label_result);
	}
	/* fork into a private mount namespace: CLONE_NEWNS | SIGCHLD */
	s64 pid = sc6(NR_clone, 0x20000 | 17, 0, 0, 0, 0, 0);
	if (pid == 0) {
		logger();
		sc(NR_exit, 0, 0, 0, 0);
	}
	sc(NR_close, kin, 0, 0, 0);
	sc(NR_close, kw, 0, 0, 0);
	sc(NR_execve, "/init.real", argv, envp, 0);
	sc(NR_exit, 1, 0, 0, 0);
}
