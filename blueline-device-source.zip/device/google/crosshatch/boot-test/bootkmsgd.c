/*
 * bootkmsgd: second-stage Android kernel-log capture for Blueline diagnostics.
 * Launched by init after SELinux policy is loaded, so this process runs in an
 * explicit vendor domain instead of inheriting first-stage init's kernel SID.
 */
#define _GNU_SOURCE

#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/system_properties.h>
#include <time.h>
#include <unistd.h>

#define LOG_PATH "/metadata/boot-kmsg-stage3.txt"
#define KMSG_CAP (2U * 1024U * 1024U)
#define HEARTBEAT_MS 5000U
#define MAX_HEARTBEATS 36U
#define MAX_CAPTURE_MS 180000U

static int output_fd = -1;
static size_t bytes_written;

static int write_all(int fd, const char *data, size_t size) {
    size_t offset = 0;
    while (offset < size) {
        ssize_t n = write(fd, data + offset, size - offset);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) return -1;
        offset += (size_t)n;
    }
    return 0;
}

static int append_bytes(const char *data, size_t size) {
    if (bytes_written >= KMSG_CAP) return 1;

    size_t available = KMSG_CAP - bytes_written;
    size_t to_write = size < available ? size : available;
    if (write_all(output_fd, data, to_write) < 0) return -1;
    bytes_written += to_write;

    // Keep the earliest boot messages. Wrapping this file loses the BPF
    // verifier output once repeated service restarts fill the metadata log.
    return to_write < size || bytes_written >= KMSG_CAP ? 1 : 0;
}

static int log_line(const char *format, ...) {
    char buffer[512];
    va_list args;
    va_start(args, format);
    int length = vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    if (length < 0) return -1;
    size_t size = (size_t)length;
    if (size >= sizeof(buffer)) size = sizeof(buffer) - 1;
    if (append_bytes(buffer, size) < 0) return -1;
    return fdatasync(output_fd);
}

static uint64_t monotonic_ms(void) {
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) < 0) return 0;
    return (uint64_t)ts.tv_sec * 1000U + (uint64_t)ts.tv_nsec / 1000000U;
}

int main(void) {
    char boot_mode[PROP_VALUE_MAX] = {0};
    if (__system_property_get("ro.boot.mode", boot_mode) > 0 &&
        strcmp(boot_mode, "recovery") == 0) {
        return 0;
    }

    output_fd = open(LOG_PATH, O_WRONLY | O_CREAT | O_TRUNC | O_APPEND | O_SYNC | O_CLOEXEC,
                     0644);
    if (output_fd < 0) return 2;

    static const char header[] = "\n===== bootlog31 stage2 logger started =====\n";
    if (append_bytes(header, sizeof(header) - 1) < 0 || fdatasync(output_fd) < 0) return 3;

    int kmsg_fd = -1;
    int first_open_errno = 0;
    int last_open_errno = 0;
    for (unsigned int attempt = 0; attempt < 60 && kmsg_fd < 0; ++attempt) {
        kmsg_fd = open("/dev/kmsg", O_RDONLY | O_NONBLOCK | O_CLOEXEC);
        if (kmsg_fd >= 0) break;
        last_open_errno = errno;
        if (attempt == 0) first_open_errno = last_open_errno;
        struct timespec retry_delay = {.tv_sec = 0, .tv_nsec = 100000000L};
        nanosleep(&retry_delay, NULL);
    }
    if (kmsg_fd < 0) {
        log_line("bootlog31: open /dev/kmsg failed after 60 attempts: first_errno=%d last_errno=%d\n",
                 first_open_errno, last_open_errno);
        return 4;
    }
    off_t seek_result = lseek(kmsg_fd, 0, SEEK_SET);
    if (log_line("bootlog31: kmsg seek result %lld\n", (long long)seek_result) < 0) return 5;

    const uint64_t capture_started = monotonic_ms();
    unsigned int heartbeats = 0;
    uint64_t last_heartbeat = monotonic_ms();
    char buffer[8192];
    struct pollfd descriptor = {.fd = kmsg_fd, .events = POLLIN};

    for (;;) {
        int ready = poll(&descriptor, 1, 1000);
        if (ready < 0 && errno != EINTR) {
            log_line("bootlog31: poll failed: errno=%d\n", errno);
            return 6;
        }

        if (ready > 0 && (descriptor.revents & (POLLIN | POLLERR | POLLHUP))) {
            ssize_t n = read(kmsg_fd, buffer, sizeof(buffer));
            if (n > 0) {
                int result = append_bytes(buffer, (size_t)n);
                if (result < 0 || fdatasync(output_fd) < 0) return 7;
                if (result > 0) return 0;
            } else if (n < 0 && errno == EPIPE) {
                if (log_line("bootlog31: kmsg reader overrun; resuming at oldest retained record\n") < 0)
                    return 8;
            } else if (n < 0 && errno != EINTR && errno != EAGAIN && errno != EWOULDBLOCK) {
                log_line("bootlog31: read /dev/kmsg failed: errno=%d\n", errno);
                return 9;
            }
        }

        uint64_t now = monotonic_ms();
        if (now >= capture_started && now - capture_started >= MAX_CAPTURE_MS) {
            log_line("bootlog31: stage2 capture window ended\n");
            return 0;
        }

        if (now >= last_heartbeat && now - last_heartbeat >= HEARTBEAT_MS &&
            heartbeats < MAX_HEARTBEATS) {
            if (log_line("bootlog31: stage2 heartbeat %u\n", ++heartbeats) < 0) return 10;
            last_heartbeat = now;
        }
    }
}
