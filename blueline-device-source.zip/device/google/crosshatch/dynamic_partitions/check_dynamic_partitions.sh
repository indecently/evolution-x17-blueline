#!/system/bin/sh

# This check prevents applying a regular dynamic-partition OTA to an older
# blueline/crosshatch build that still expects physical partitions.
DP_PROPERTY_NAME="ro.boot.dynamic_partitions"
DP_RETROFIT_PROPERTY_NAME="ro.boot.dynamic_partitions_retrofit"

DP_PROPERTY=$(getprop "${DP_PROPERTY_NAME}")
DP_RETROFIT_PROPERTY=$(getprop "${DP_RETROFIT_PROPERTY_NAME}")

if [ "${DP_PROPERTY}" != "true" ] || [ "${DP_RETROFIT_PROPERTY}" != "true" ]; then
    echo "Error: this OTA requires retrofit dynamic partitions."
    echo "${DP_PROPERTY_NAME}=${DP_PROPERTY}"
    echo "${DP_RETROFIT_PROPERTY_NAME}=${DP_RETROFIT_PROPERTY}"
    exit 1
fi
