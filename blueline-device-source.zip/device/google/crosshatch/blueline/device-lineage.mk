#
# Copyright (C) 2018-2021 The LineageOS Project
#
# SPDX-License-Identifier: Apache-2.0
#

$(call inherit-product, device/google/crosshatch/device-lineage.mk)

# This Android 17 port retains the Pixel 3's legacy vendor policy. Keep runtime
# SELinux enforcing while treating newer Treble app-label coverage as warnings.
PRODUCT_ENFORCE_SELINUX_TREBLE_LABELING := false

# Blueline retains the 4.9 kernel, which has no kernel FCM 7 entry in the
# Android 17 compatibility matrix. Keep VINTF HAL checks enabled, but omit
# the kernel-FCM OTA gate so the legacy device can produce an installable OTA.
PRODUCT_OTA_ENFORCE_VINTF_KERNEL_REQUIREMENTS := false

# The Android 17 libui mapper path is newer than the mapper exposed by the
# Pixel 3's legacy Qualcomm gralloc stack.
$(call soong_config_set_bool,libui,legacy_gralloc,true)
