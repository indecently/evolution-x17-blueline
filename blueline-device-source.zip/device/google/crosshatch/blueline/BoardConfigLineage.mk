#
# Copyright (C) 2018-2021 The LineageOS Project
#
# SPDX-License-Identifier: Apache-2.0
#

include device/google/crosshatch/BoardConfigLineage.mk

include vendor/google/blueline/BoardConfigVendor.mk

# Build the normal A/B OTA; the legacy retrofit-only package has no block-map
# inputs on this Android 17 target and is not required for Recovery sideload.
BOARD_BUILD_RETROFIT_DYNAMIC_PARTITIONS_OTA_PACKAGE := false
