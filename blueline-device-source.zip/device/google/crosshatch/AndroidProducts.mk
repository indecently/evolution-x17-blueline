#
# Copyright 2015 The Android Open Source Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

PRODUCT_MAKEFILES := \
    $(LOCAL_DIR)/aosp_crosshatch.mk \
    $(LOCAL_DIR)/aosp_blueline.mk \
    $(LOCAL_DIR)/aosp_crosshatch_hwasan.mk \
    $(LOCAL_DIR)/aosp_blueline_hwasan.mk \
    $(LOCAL_DIR)/vf/aosp_crosshatch_vf.mk \
    $(LOCAL_DIR)/lineage_blueline.mk \
    $(LOCAL_DIR)/lineage_crosshatch.mk

COMMON_LUNCH_CHOICES := \
    aosp_crosshatch-userdebug \
    aosp_blueline-userdebug \
    aosp_crosshatch_vf-userdebug \
    lineage_blueline-userdebug \
    lineage_crosshatch-userdebug
