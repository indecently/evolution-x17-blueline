Pixel 3 Evolution X 17 local source changes.
Device tree is published separately as blueline-device-source.zip.
For each BASES.tsv row, check out the listed base commit in the indicated repo,
then apply its patch with git apply. Base commit availability and a clean
rebuild are not verified. This is not a pinned sync manifest.
The unused 4.19 experiment and proprietary binaries are excluded.
Vendor dependencies must be obtained from authorized sources.
