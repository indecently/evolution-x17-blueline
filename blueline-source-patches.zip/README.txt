Pixel 3 (blueline) Evolution X 17 source changes — 2026-11-28

This archive contains text/source patches for the modified repositories listed in BASES.tsv. The device tree is supplied separately as blueline-device-source.zip. Apply each patch only at the exact base commit recorded in BASES.tsv. The active B1C1 kernel is supplied both as a complete source archive in the kernel release and as a review patch here.

The unused SDM845 4.19 kernel experiment and proprietary binaries are excluded. The six locally modified proprietary blobs are listed in OMITTED.txt; obtain permitted matching inputs and follow VENDOR-BLOBS.md. This source package does not claim that a clean public checkout has been rebuilt from scratch.
